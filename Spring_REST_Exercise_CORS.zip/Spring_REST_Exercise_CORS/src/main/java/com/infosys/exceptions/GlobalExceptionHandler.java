package com.infosys.exceptions;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice

public class GlobalExceptionHandler {
	
	@Autowired
	private Environment env;
	

//	@ExceptionHandler(Exception.class)
//	public ResponseEntity<ErrorMessage> generalExceptionHandler(Exception ex){
//		ErrorMessage error=new ErrorMessage();
//		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
//		error.setMessage(env.getProperty("GENERAL_EXCEPTION_MESSAGE"));
//		return new ResponseEntity<ErrorMessage>(error,HttpStatus.INTERNAL_SERVER_ERROR);
//		
//	}
	//Handler for ProductNotFoundException
	
	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorMessage> productNotFoundExceptionHandler(ProductNotFoundException ex){
		ErrorMessage error=new ErrorMessage();
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		error.setMessage(ex.getMessage());
		return new ResponseEntity<ErrorMessage>(error,HttpStatus.NOT_FOUND);
		
	}
	
	//Handler for validation failures w.r.t DTOs
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> methodArgumentExceptionHandler(MethodArgumentNotValidException ex){
		ErrorMessage error=new ErrorMessage();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setMessage(ex.getBindingResult().getAllErrors().stream().map(ObjectError::getDefaultMessage)
		                                                             .collect(Collectors.joining(",")));
		
		return new ResponseEntity<ErrorMessage>(error,HttpStatus.BAD_REQUEST);
		
	}
	
	

}
