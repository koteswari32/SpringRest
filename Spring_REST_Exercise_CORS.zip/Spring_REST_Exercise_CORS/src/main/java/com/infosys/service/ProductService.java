package com.infosys.service;

import java.util.List;

import com.infosys.dto.ProductDTO;
import com.infosys.dto.ProductDTOVersion2;
import com.infosys.exceptions.ProductNotFoundException;

public interface ProductService {
	
	public String insertProduct(ProductDTO dto);
	
	public List<ProductDTO> getProducts(String productName);
	
	public List<ProductDTOVersion2> getProductsByNameAndVendor(String productName,String productVendor);
	
	public String deleteProductByCode(Long productCode) throws ProductNotFoundException;

}
