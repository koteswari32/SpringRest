package com.infosys.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.infosys.domain.Product;
import com.infosys.dto.ProductDTO;
import com.infosys.dto.ProductDTOVersion2;
import com.infosys.exceptions.ProductNotFoundException;
import com.infosys.repository.ProductRepository;

@Service
@PropertySource("classpath:ValidationMessages.properties")
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository repo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	//To add the product to db
	public String insertProduct(ProductDTO dto) {
		
		//Without using model mapper
//		Product p=new Product();
//	    p=repo.save(ProductDTO.prepareProductEntity(dto));
		//modelMapper.map(source,destination) IoC container will take of it
		
		Product p=repo.save(modelMapper.map(dto, Product.class));
		
		return "Product "+p.getProductName()+" added successfully";
	}

	//To get the product details based on productName
	@Override
	public List<ProductDTO> getProducts(String productName) {
		List<Product> plist=repo.findByProductName(productName);
		List<ProductDTO> productDtoList=new ArrayList<>();
		for(Product p:plist) {
			ProductDTO productDto=modelMapper.map(p, ProductDTO.class);
			productDtoList.add(productDto);
		}
		
	    return productDtoList;
	}

	//To get products by productname and vendor
	@Override
	public List<ProductDTOVersion2> getProductsByNameAndVendor(String productName, String productVendor) {
		
		List<Product> plist=repo.getProductsByNameVendor(productName, productVendor);
		List<ProductDTOVersion2> productDTOlist=new ArrayList<>();
		
		for(Product p:plist) {
			ProductDTOVersion2 productDTO=modelMapper.map(p, ProductDTOVersion2.class);
			productDTOlist.add(productDTO);
		}
		
		return productDTOlist;
	}


	@Override
	public String deleteProductByCode(Long productCode) throws ProductNotFoundException{
		
		repo.deleteProductByCode(productCode);
		
		return "Product Deleted";
	}
	

	

}
