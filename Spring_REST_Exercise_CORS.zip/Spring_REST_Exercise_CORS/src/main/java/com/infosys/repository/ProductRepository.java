package com.infosys.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.domain.Product;




@Repository
public interface ProductRepository extends CrudRepository<Product, Integer>{
	
	//Using query by method name 
	 public List<Product> findByProductName(String productName);
	 
	 //Position based query
	 @Query("select p from Product p where p.productName=?1 and p.productVendor=?2")
	 public List<Product> getProductsByNameVendor(String productName,String productVendor);
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 //Query for deleting product based on productCode
	 @Query("DELETE FROM Product p where p.productCode=?1")
	 @Modifying
	 @Transactional
	 public void deleteProductByCode(Long productCode);

}
