package com.infosys;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//To enable CORS(Cross Origin Resource Sharing) we have to implements WebMvcConfigurer and Override the
//addCorsMappings() method
@SpringBootApplication
public class SpringRestExercise2Application implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(SpringRestExercise2Application.class, args);
	}
	
	
	//Here CorsRegistry is the class
	@Override
	public void addCorsMappings(CorsRegistry registry) {
			
			registry.addMapping("/**").allowedMethods("GET","POST");
			
	}
	
	//We can give this modelmapper dependecy in application class instead of creating configuration class
	
//	@Bean
//	public ModelMapper modelMapper() {
//		//ModelMapper modelMapper=new ModelMapper();
//		return new ModelMapper();
//	}

}
