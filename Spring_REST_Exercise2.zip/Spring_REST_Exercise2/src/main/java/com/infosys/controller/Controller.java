package com.infosys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.ProductDTO;
import com.infosys.service.ProductService;

@RestController
@RequestMapping("/product")
public class Controller {
	
	@Autowired
	ProductService service;
	
	@PostMapping
	public ResponseEntity<String> insertProduct(@RequestBody ProductDTO productDto) {
		
		String product=service.insertProduct(productDto);
		
		return new ResponseEntity<>(product,HttpStatus.ACCEPTED);
	}

}
