package com.infosys.domain;

import com.infosys.dto.ProductDTO;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Product04")
public class Product {
	
	@Id
	private Integer productId;
	private String productName;
	private String productVendor;
	private Double productPrice;
	private String productInStock;
	
	public Product() {
		
	}
	
	public Product(Integer productId, String productName, String productVendor, Double productPrice,
			String productInStock) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productVendor = productVendor;
		this.productPrice = productPrice;
		this.productInStock = productInStock;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductVendor() {
		return productVendor;
	}

	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductInStock() {
		return productInStock;
	}

	public void setProductInStock(String productInStock) {
		this.productInStock = productInStock;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productVendor=" + productVendor
				+ ", productPrice=" + productPrice + ", productInStock=" + productInStock + "]";
	}
	
	public static ProductDTO prepareProductDTO(Product product) {
		ProductDTO dto=new ProductDTO();
		dto.setProductId(product.getProductId());
		dto.setProductName(product.getProductName());
		dto.setProductVendor(product.getProductVendor());
		dto.setProductPrice(product.getProductPrice());
		dto.setProductInStock(product.getProductInStock());
		
		return dto;
		
		
		
	}
	
	
}
