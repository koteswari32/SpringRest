package com.infosys.service;

import com.infosys.dto.ProductDTO;

public interface ProductService {
	
	public String insertProduct(ProductDTO dto);

}
