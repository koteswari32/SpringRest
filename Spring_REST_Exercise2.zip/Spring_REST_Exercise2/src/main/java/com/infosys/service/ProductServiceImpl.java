package com.infosys.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Product;
import com.infosys.dto.ProductDTO;
import com.infosys.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository repo;
	
	public String insertProduct(ProductDTO dto) {
		
		Product p=new Product();
	    p=repo.save(ProductDTO.prepareProductEntity(dto));
		
		return "Product "+p.getProductName()+" added successfully";
	}
	

	

}
