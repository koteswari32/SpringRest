package com.infosys.service;

public interface CookPickService {

	public String greet();
}
