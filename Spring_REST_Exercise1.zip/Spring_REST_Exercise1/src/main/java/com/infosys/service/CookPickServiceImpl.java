package com.infosys.service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

@Service
public class CookPickServiceImpl implements CookPickService{
	
	
	public String greet() {
		
		LocalDate date=LocalDate.now();
		String day=date.getDayOfWeek().toString().toLowerCase();
		
		
	   return "Welcome to "+day+" sale";
	}

}
