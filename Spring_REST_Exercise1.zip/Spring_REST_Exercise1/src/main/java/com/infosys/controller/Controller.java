package com.infosys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.service.CookPickService;

@RestController
@RequestMapping("/greet")
public class Controller {
	
	@Autowired
	CookPickService service;
	
	@GetMapping
	public String greet() {
		return service.greet();
	}

}
