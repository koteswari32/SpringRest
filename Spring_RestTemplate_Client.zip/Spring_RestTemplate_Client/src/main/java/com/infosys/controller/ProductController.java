package com.infosys.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.ProductDTO;
import com.infosys.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	
	@Autowired
	private ProductService service;
	
	
	//http://localhost:8086/products?productName=**
	@GetMapping
	
	public ResponseEntity<List<ProductDTO>> fetchProducts(@RequestParam String productName){
		
		List<ProductDTO> products=service.fetchProduct(productName);
		
		return new ResponseEntity<>(products,HttpStatus.OK);
		
	}

}
