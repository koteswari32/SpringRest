package com.infosys.service;

import java.util.List;

import com.infosys.dto.ProductDTO;

public interface ProductService {
	
	public List<ProductDTO> fetchProduct(String productName);

}
