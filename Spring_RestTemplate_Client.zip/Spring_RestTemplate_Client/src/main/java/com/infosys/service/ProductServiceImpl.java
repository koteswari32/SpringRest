package com.infosys.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infosys.dto.ProductDTO;
import com.infosys.dto.VendorDTO;
import com.infosys.entity.Product;
import com.infosys.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	
	@Autowired
	private ProductRepository repo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	
	@Override
	public List<ProductDTO> fetchProduct(String productName) {
		
		List<Product> plist=repo.findByProductName(productName);
		List<ProductDTO> pdto=new ArrayList<>();
		for(Product p:plist) {
			//String name=p.getProductName();
			Integer vendor=p.getVendorId();
			ResponseEntity<VendorDTO> v=restTemplate.getForEntity("http://localhost:8090/products/"+vendor, VendorDTO.class);
			VendorDTO venderDTO=v.getBody();
			ProductDTO productDTO=modelMapper.map(p, ProductDTO.class);
			productDTO.setVendorDTO(venderDTO);
			pdto.add(productDTO);
			
			
		}
		
		return pdto;
	}

}
