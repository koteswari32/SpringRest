package com.infosys.dto;

public class ProductDTO {
	
	private Integer productId;
	private String productName;
	private Double productPrice;
	private String productInStock;
	private Long productCode;
	private VendorDTO vendorDTO;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductInStock() {
		return productInStock;
	}
	public void setProductInStock(String productInStock) {
		this.productInStock = productInStock;
	}
	public Long getProductCode() {
		return productCode;
	}
	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}
	public VendorDTO getVendorDTO() {
		return vendorDTO;
	}
	public void setVendorDTO(VendorDTO vendorDTO) {
		this.vendorDTO = vendorDTO;
	}
	@Override
	public String toString() {
		return "ProductDTO [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productInStock=" + productInStock + ", productCode=" + productCode + ", vendorDTO=" + vendorDTO
				+ "]";
	}
	
	

}
