package com.infosys.dto;

public class VendorDTO {

	private Integer vendorId;
	//private String productName;
	private String productVendor;
	
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
//	public String getProductName() {
//		return productName;
//	}
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}
	public String getProductVendor() {
		return productVendor;
	}
	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}
	@Override
	public String toString() {
		return "VendorDTO [vendorId=" + vendorId + ", productVendor=" + productVendor + "]";
	}
	
	
	
}
