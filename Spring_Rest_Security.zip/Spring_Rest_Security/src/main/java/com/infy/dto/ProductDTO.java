package com.infy.dto;

public class ProductDTO {
	
	private Integer productId;
	private String productName;
	private String productVendor;
	private Double productPrice;
	private Boolean productInStock;
	private Long productCode;
	
	public ProductDTO() {
		
	}

	public ProductDTO(Integer productId, String productName, String productVendor, Double productPrice,
			Boolean productInStock, Long productCode) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productVendor = productVendor;
		this.productPrice = productPrice;
		this.productInStock = productInStock;
		this.productCode = productCode;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductVendor() {
		return productVendor;
	}

	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public Boolean getProductInStock() {
		return productInStock;
	}

	public void setProductInStock(Boolean productInStock) {
		this.productInStock = productInStock;
	}

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	@Override
	public String toString() {
		return "ProductDTO [productId=" + productId + ", productName=" + productName + ", productVendor="
				+ productVendor + ", productPrice=" + productPrice + ", productInStock=" + productInStock
				+ ", productCode=" + productCode + "]";
	}
	
	
	

}
