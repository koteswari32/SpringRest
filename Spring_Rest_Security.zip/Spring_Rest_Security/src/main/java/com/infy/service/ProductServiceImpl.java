package com.infy.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.ProductDTO;
import com.infy.entity.Product;
import com.infy.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository repo;
	
	@Autowired
	private ModelMapper modelMapper;

	
	//To insert Product details
	@Override
	public String insertProduct(ProductDTO productDto) {
		
	   Product p=repo.save(modelMapper.map(productDto, Product.class));
		
		return "Product "+p.getProductName()+" added successfully";
	}
	
	

}
