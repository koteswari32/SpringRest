package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.ProductDTO;
import com.infy.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	private ProductService service;
	
	//http://localhost:8085/products
	@PostMapping
	public ResponseEntity<String> addProduct(@RequestBody ProductDTO productDto){
		
		String s=service.insertProduct(productDto);
		return new ResponseEntity<String>(s,HttpStatus.CREATED);
		
	}

}
