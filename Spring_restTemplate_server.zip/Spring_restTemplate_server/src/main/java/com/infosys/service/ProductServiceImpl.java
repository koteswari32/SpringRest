package com.infosys.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.domain.Product;
import com.infosys.dto.ProductDTO;
import com.infosys.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	 private ProductRepository repo;
	
	@Autowired
	 private ModelMapper modelMapper;

//	@Override
//	public List<ProductDTO> getProductsByNameAndVendor(String productName, String productVendor) {
//		List<Product> plist=repo.getProductsByNameVendor(productName, productVendor);
//		List<ProductDTO> productDtoList=new ArrayList<>();
//		for(Product p:plist) {
//			ProductDTO dto=modelMapper.map(p, ProductDTO.class);
//			productDtoList.add(dto);
//		}
//		return productDtoList;
//	}

	@Override
	public ProductDTO fetchVendorById(Integer vendorId) {
		Optional<Product> product=repo.findById(vendorId);

		Product p=new Product();
		
		p.setProductVendor("nosuchvendor");
		Product pro=product.orElse(p);
		
		return modelMapper.map(pro, ProductDTO.class);
	}
	
	
//	public String insertProduct(ProductDTO dto) {
//		
//		Product p=repo.save(modelMapper.map(dto, Product.class));
//		
//		return "Product "+p.getProductName()+" added successfully";
//	}

}
