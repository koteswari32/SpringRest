package com.infosys.service;

import java.util.List;

import com.infosys.dto.ProductDTO;

public interface ProductService {

//	public List<ProductDTO> getProductsByNameAndVendor(String productName,String productVendor);
	
	//public String insertProduct(ProductDTO dto);
	
	public ProductDTO fetchVendorById(Integer vendorId);
}
