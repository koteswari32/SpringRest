package com.infosys.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.ProductDTO;
import com.infosys.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductService service;
	
	//http://localhost:8090/product?productName=**&productVendor=**
//	@GetMapping
//	public ResponseEntity<List<ProductDTO>> fetchProductsByNameAndVendor(@RequestParam String productName,@RequestParam String productVendor){
//		
//		List<ProductDTO> list=service.getProductsByNameAndVendor(productName, productVendor);
//		return new ResponseEntity<>(list,HttpStatus.ACCEPTED);
//	}
	
	//http://localhost:8091/products/101
	@GetMapping(value="/{vendorId}")
	public ResponseEntity<ProductDTO> fetchVendorById(@PathVariable Integer vendorId){
		ProductDTO p=service.fetchVendorById(vendorId);
		return new ResponseEntity<>(p,HttpStatus.FOUND);
	}
	
//	@PostMapping 
//	public ResponseEntity<String> addProduct(@RequestBody ProductDTO productDto){
//		String product=service.insertProduct(productDto);
//		return new ResponseEntity<>(product,HttpStatus.CREATED);
//	}
	
	
}
