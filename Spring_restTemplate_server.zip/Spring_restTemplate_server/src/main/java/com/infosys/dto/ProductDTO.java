package com.infosys.dto;

public class ProductDTO {
	private Integer vendorId;
	//private String productName;
	private String productVendor;
	
	public ProductDTO() {
		
	}



	public ProductDTO(Integer vendorId, String productName, String productVendor) {
		super();
		this.vendorId = vendorId;
		//this.productName = productName;
		this.productVendor = productVendor;
	}

	public Integer getVendorId() {
		return vendorId;
	}



	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}



//	public String getProductName() {
//		return productName;
//	}
//
//	public void setProductName(String productName) {
//		this.productName = productName;
//	}

	public String getProductVendor() {
		return productVendor;
	}


	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}





	@Override
	public String toString() {
		return "ProductDTO [vendorId=" + vendorId + ", productVendor=" + productVendor + "]";
	}


	
	
	
}
