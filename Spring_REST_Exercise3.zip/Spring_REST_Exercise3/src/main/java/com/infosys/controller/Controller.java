package com.infosys.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.ProductDTO;
import com.infosys.dto.ProductDTOVersion2;
import com.infosys.exceptions.ProductNotFoundException;
import com.infosys.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/product")
public class Controller {
	
	@Autowired
	ProductService service;
	
	//@Valid to validate the productDTO data
	//http://localhost:8085/product
	@PostMapping
	public ResponseEntity<String> insertProduct(@RequestBody @Valid ProductDTO productDto) {
		
		String product=service.insertProduct(productDto);
		
		return new ResponseEntity<>(product,HttpStatus.CREATED);
	}
	
	//Using @PathVariable
	
	//http://localhost:8085/product/productName?version=1
	
	@GetMapping(value="/{productName}",params="version=1")
	public ResponseEntity<List<ProductDTO>> getProducts(@PathVariable String productName){
		
		List<ProductDTO> products=service.getProducts(productName);
		
		return new ResponseEntity<>(products,HttpStatus.ACCEPTED);
	}
	
	//Using Request Param
	//http://localhost:8085/product?productName=Bag&productVendor=Safari&version=2
	
	@GetMapping(params="version=2")
	public ResponseEntity<List<ProductDTOVersion2>> getProductsByNameAndVendor(@RequestParam String productName,@RequestParam String productVendor){
		
		List<ProductDTOVersion2> products=service.getProductsByNameAndVendor(productName, productVendor);
		
		return new ResponseEntity<>(products,HttpStatus.ACCEPTED);
	}
	
	
	
	
	
	//Delete record using productCode and throwing exception
	//http://localhost:8085/product/productCode
	
	@DeleteMapping(value="/{productCode}")
	public ResponseEntity<String> deleteProduct(@PathVariable Long productCode) throws ProductNotFoundException{
		
		String str=service.deleteProductByCode(productCode);
		
		return new ResponseEntity<>(str,HttpStatus.OK);
		
	}

}
