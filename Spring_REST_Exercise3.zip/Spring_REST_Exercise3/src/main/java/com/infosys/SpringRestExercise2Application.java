package com.infosys;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringRestExercise2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestExercise2Application.class, args);
	}
	
	//We can give this modelmapper dependecy in application class instead of creating configuration class
	
//	@Bean
//	public ModelMapper modelMapper() {
//		//ModelMapper modelMapper=new ModelMapper();
//		return new ModelMapper();
//	}

}
